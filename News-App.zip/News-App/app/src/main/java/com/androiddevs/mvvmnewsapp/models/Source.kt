package com.androiddevs.mvvmnewsapp.models


import com.google.gson.annotations.SerializedName

data class Source(
    val id: Any,
    val name: String
)