package com.androiddevs.mvvmnewsapp

import android.app.Application

class NewsApplication : Application()