package com.netcompss.ffmpeg4android;

public class Prefs {
	public static final String TAG = "ffmpeg4android";
	public static final String version = "41.09.00_LM41_00";

}
