package com.netcompss.ffmpeg4android;

public class CommandValidationException extends Exception {
	private static final long serialVersionUID = 1L;
}
